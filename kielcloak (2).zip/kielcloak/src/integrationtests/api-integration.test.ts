import request from "supertest";
import { GenericContainer, StartedTestContainer, Wait } from "testcontainers";
import path from "path";

describe("Backend Integration Tests", () => {
  let backendContainer: StartedTestContainer;
  let baseURL: string;

  beforeAll(async () => {
    console.log("\n🚀 Starting backend container via Testcontainers...");

    const projectRoot = process.cwd();
    
    // Lade Umgebungsvariablen aus .env falls vorhanden
    const envVars = {
      CLIENT_ID: process.env.CLIENT_ID || "test-client-id",
      CLIENT_SECRET: process.env.CLIENT_SECRET || "test-client-secret",
      OIDC_ISSUER: process.env.OIDC_ISSUER || "http://localhost:3000",
      NODE_ENV: "test",
    };

    try {
      // Starte Backend in Docker-Container
      backendContainer = await new GenericContainer("node:22")
        .withBindMounts([
          {
            source: projectRoot,
            target: "/app",
            mode: "rw",
          },
        ])
        .withCommand([
          "sh",
          "-c",
          "cd /app && npm install && npm run dev",
        ])
        .withEnvironment(envVars)
        .withExposedPorts(8080)
        .withWaitStrategy(Wait.forLogMessage("Server running on"))
        .withStartupTimeout(120000)
        .start();

      // Hole dynamischen Port
      const port = backendContainer.getMappedPort(8080);
      const host = backendContainer.getHost();
      baseURL = `http://${host}:${port}`;

      console.log(`✅ Backend container started at ${baseURL}`);

      // Warte zusätzlich bis Backend wirklich ready ist
      await waitForBackend(baseURL, 60000);
      console.log(`✅ Backend is responsive\n`);
    } catch (error) {
      console.error("❌ Failed to start backend container:", error);
      throw error;
    }
  }, 180000);

  afterAll(async () => {
    if (backendContainer) {
      console.log("\n🛑 Stopping backend container...");
      try {
        await backendContainer.stop();
        console.log("✅ Backend container stopped\n");
      } catch (error) {
        console.error("❌ Error stopping backend container:", error);
      }
    }
  });

  describe("GET /test", () => {
    it("should return OK from running backend", async () => {
      const response = await request(baseURL)
        .get("/test")
        .set("User-Agent", "Integration-Test");

      expect(response.status).toBe(200);
      expect(response.text).toBe("OK");
    });
  });

  describe("POST /save_address - Integration Tests", () => {
    it("should save address with valid data to backend", async () => {
      const payload = {
        sourceURL: "https://source.example.com/data",
        destinations: [
          "https://dest1.example.com/data",
          "https://dest2.example.com/data",
        ],
      };

      const response = await request(baseURL)
        .post("/save_address")
        .set("Content-Type", "application/json")
        .send(payload);

      expect(response.status).toBe(200);
    });

    it("should accept requests with missing destinations", async () => {
      const payload = {
        sourceURL: "https://source.example.com/data",
      };

      const response = await request(baseURL)
        .post("/save_address")
        .send(payload);

      expect(response.status).toBe(200);
    });

    it("should accept requests with empty destinations array", async () => {
      const payload = {
        sourceURL: "https://source.example.com/data",
        destinations: [],
      };

      const response = await request(baseURL)
        .post("/save_address")
        .send(payload);

      expect(response.status).toBe(200);
    });
  });

  describe("SOLID Data Flow Integration", () => {
    it("should handle SOLID data format", async () => {
      const payload = {
        sourceURL: "https://pod.example.com/public/data.ttl",
        destinations: ["https://other-pod.example.com/inbox/"],
      };

      const response = await request(baseURL)
        .post("/save_address")
        .send(payload);

      expect(response.status).toBe(200);
    });
  });

  describe("Performance & Stability", () => {
    it("should handle multiple concurrent requests", async () => {
      const payload = {
        sourceURL: "https://source.example.com/data",
        destinations: ["https://dest.example.com/data"],
      };

      const requests = Array(5)
        .fill(null)
        .map(() => request(baseURL).post("/save_address").send(payload));

      const responses = await Promise.all(requests);

      responses.forEach((response) => {
        expect(response.status).toBe(200);
      });
    });

    it("should handle large destination lists", async () => {
      const largeDestinations = Array(100)
        .fill(null)
        .map((_, i) => `https://dest${i}.example.com/data`);

      const payload = {
        sourceURL: "https://source.example.com/data",
        destinations: largeDestinations,
      };

      const response = await request(baseURL)
        .post("/save_address")
        .send(payload);

      expect(response.status).toBe(200);
    });
  });

  describe("Error Handling", () => {
    it("should handle requests with missing destinations", async () => {
      const response = await request(baseURL)
        .post("/save_address")
        .send({ sourceURL: "https://example.com/data" });

      expect(response.status).toBe(200);
    });

    it("should handle malformed JSON gracefully", async () => {
      const response = await request(baseURL)
        .post("/save_address")
        .set("Content-Type", "application/json")
        .send("{ invalid json }");

      expect([400, 500]).toContain(response.status);
    });
  });
});

/**
 * Wartet bis der Backend-Server antwortet
 */
async function waitForBackend(url: string, timeoutMs: number): Promise<void> {
  const startTime = Date.now();
  const interval = 500; // Check alle 500ms

  while (Date.now() - startTime < timeoutMs) {
    try {
      const response = await request(url)
        .get("/test")
        .timeout(2000);

      if (response.status === 200) {
        return;
      }
    } catch (err) {
      // Backend antwortet noch nicht, versuche es nochmal
    }

    await new Promise((resolve) => setTimeout(resolve, interval));
  }

  throw new Error(`Backend did not respond within ${timeoutMs}ms`);
}
