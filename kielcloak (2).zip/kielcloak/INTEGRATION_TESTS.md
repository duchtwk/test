# Kielcloak Integration Tests - Vollständige Anleitung

Diese Integration-Tests nutzen **Testcontainers** um den KielCloak Backend **automatisch** in einem Docker-Container zu starten, sodass die Tests überall laufen — lokal, in GitLab CI — **ohne manuelles Docker Setup**.

## Wichtig: Docker DinD in GitLab CI

Tests brauchen Docker zur Laufzeit. In der GitLab CI Pipeline wird **Docker-in-Docker (DinD)** verwendet, damit Testcontainers funktioniert.

## Setup lokal

### 1. Dependencies installieren

```bash
npm install
```

Das installiert `testcontainers@^11.8.0` (aktualisiert von v10.5.0).

### 2. Docker/Podman starten

```bash
docker --version   # oder: podman --version
docker ps          # Prüfe, dass es läuft
```

## Tests ausführen

### Unit Tests (ohne Dependencies)
```bash
npm test
```

### Integration Tests (mit Backend Container)
```bash
npm run test:integration
```

### Integration Tests im Watch Mode
```bash
npm run test:integration:watch
```

### Mit Coverage
```bash
npm run test:coverage
```

## Architektur - Wie Testcontainers funktioniert

```
Jest Integration Test Suite (api-integration.test.ts)
    ↓ beforeAll()
GenericContainer("node:22")  ← Startet neuen Container
    ↓ Mount Projekt + npm install + npm run dev
Backend läuft auf zufälligem Port (z.B. 127.0.0.1:45023)
    ↓ Requests via supertest
Tests überprüfen Backend-Endpoints
    ↓ afterAll()
Container stoppt + cleanup
```

## Best Practices (vom frontend-v2 Repo übernommen)

### 1. Environment Variablen mit Defaults

```typescript
const envVars = {
  CLIENT_ID: process.env.CLIENT_ID || "test-client-id",
  CLIENT_SECRET: process.env.CLIENT_SECRET || "test-client-secret",
  OIDC_ISSUER: process.env.OIDC_ISSUER || "http://localhost:3000",
  NODE_ENV: "test",
};
```

Lokal überschreiben:
```bash
CLIENT_ID=staging npm run test:integration
```

### 2. Auf Backend-Liveness prüfen

Nicht nur auf Logs warten - auch HTTP-Probes:

```typescript
async function waitForBackend(url: string, timeoutMs: number): Promise<void> {
  while (Date.now() - startTime < timeoutMs) {
    try {
      const response = await request(url).get("/test");
      if (response.status === 200) return;
    } catch (err) {
      // Noch nicht ready
    }
    await new Promise(r => setTimeout(r, 500));
  }
  throw new Error(`Backend did not respond within ${timeoutMs}ms`);
}
```

### 3. Separate Jest Config für Integration Tests

`jest.integration.config.cjs`:
- `testMatch: ['**/src/integrationtests/**/*.test.ts']`
- `testTimeout: 120000` (2 min, nicht 5s wie Unit Tests)

### 4. Gutes Logging für Debugging

```typescript
console.log("\n🚀 Starting backend container via Testcontainers...");
console.log(`✅ Backend container started at ${baseURL}`);
console.log(`✅ Backend is responsive\n`);
```

## GitLab CI Pipeline (.gitlab-ci.yml)

```yaml
integration-tests:
  stage: test
  image: node:22
  variables:
    DEBUG: testcontainers*
    DOCKER_HOST: tcp://docker:2375
    DOCKER_TLS_VERIFY: 'false'
  services:
    - docker:20.10-dind
  script:
    - npm ci
    - npm run test:integration
  timeout: 10 minutes
```

**Schlüssel:**
- `services: - docker:20.10-dind` → Docker läuft im Container
- `DOCKER_HOST: tcp://docker:2375` → Testcontainers findet Docker DinD
- `DEBUG: testcontainers*` → Detailed Logging bei Problemen

## Troubleshooting

### Local: "Cannot connect to Docker daemon"
```bash
# Docker starten
docker ps

# Falls noch Fehler: Docker neustart
systemctl restart docker  # Linux
# oder Docker Desktop neustarten (macOS/Windows)
```

### Local: Backend startet aber Tests fehlgeschlagen
```bash
# Verbindung testen
curl http://localhost:8080/test

# Logs detailliert sehen
DEBUG=testcontainers* npm run test:integration

# Startup-Timeout erhöhen in api-integration.test.ts
.withStartupTimeout(300000)  // 5 Minuten statt 2
```

### CI: "No space left on device"
GitLab Runner hat zu wenig Platz. Alte Container löschen:
```bash
docker system prune -a  # Nur auf lokaler Dev-Maschine!
```

### CI: Service 'docker' not recognized
`.gitlab-ci.yml` nutzt falsches Format. Korrektur:
```yaml
services:
  - docker:20.10-dind
```

## Dateistruktur

```
kielcloak/
├── .gitlab-ci.yml                     ← CI Pipeline mit DinD (NEU)
├── jest.config.js                     ← Unit Tests
├── jest.integration.config.cjs        ← Integration Tests Config
├── package.json                       ← testcontainers@^11.8.0
├── src/
│   └── integrationtests/
│       └── api-integration.test.ts    ← Jest Tests (Testcontainers)
└── INTEGRATION_TESTS.md               ← Diese Datei
```

## Unterschied: Lokal vs. CI

| Aspekt | Lokal | GitLab CI |
|--------|-------|-----------|
| Docker | `docker ps` (Host) | `docker:20.10-dind` (Service) |
| Testcontainers | Findet Docker automatisch | Nutzt `DOCKER_HOST=tcp://docker:2375` |
| Port | Zufällig (z.B. 45023) | Zufällig (z.B. 45789) |
| Startup-Zeit | ~20-30s | ~30-40s (etwas langsamer in CI) |

## Commands - Zusammenfassung

```bash
npm install                      # Setup
npm test                         # Unit Tests
npm run test:coverage            # Unit Tests + Coverage
npm run test:integration         # Integration Tests (mit Docker)
npm run test:integration:watch   # Integration Tests (Watch Mode)
npm run build                    # Webpack Build
npm run dev                      # Development Server
```

## Weitere Ressourcen

- [Testcontainers Node.js](https://testcontainers.com/modules/nodejs/)
- [GenericContainer API](https://node.testcontainers.org/)
- [Jest Documentation](https://jestjs.io/docs/getting-started)
- [Docker-in-Docker Best Practices](https://docs.gitlab.com/ee/ci/docker/using_docker_build.html)
